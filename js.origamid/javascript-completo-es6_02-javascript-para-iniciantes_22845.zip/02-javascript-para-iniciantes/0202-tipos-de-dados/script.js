// Declare uma variável contendo uma string
var nome = 'André';

// Declare uma variável contendo um número dentro de uma string
var ano = '2018';

// Declare uma variável com a sua idade
var idade = 28;

// Declare duas variáveis, uma com seu nome
// e outra com seu sobrenome e some as mesmas
var sobrenome = 'Rafael'
var nomeCompleto = `${nome} ${sobrenome}`;

// Coloque a seguinte frase em uma variável: It's time
var frase = `It's time`;

// Verifique o tipo da variável que contém o seu nome
var verificarTipoNome = typeof nome;

console.log(verificarTipoNome);

// apagar
