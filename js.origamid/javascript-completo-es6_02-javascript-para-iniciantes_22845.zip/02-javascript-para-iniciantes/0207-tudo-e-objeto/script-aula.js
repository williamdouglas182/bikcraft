var nome = 'André';

var nomeMinusculo = nome.toLowerCase();

var btn = document.querySelector('.btn');
