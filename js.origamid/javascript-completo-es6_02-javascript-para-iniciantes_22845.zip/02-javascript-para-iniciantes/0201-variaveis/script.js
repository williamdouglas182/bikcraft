// Declarar uma variável com o seu nome
var nome = 'André';

// Declarar uma variável com a sua idade
var idade = 28;

// Declarar uma variável com a sua comida
// favorita e não atribuir valor
var comidaFavorita;

// Atribuir valor a sua comida favorita
comidaFavorita = 'Pizza';

// Declarar 5 variáveis diferentes sem valores
var time = 'Vasco',
  professor,
  pais,
  endereco,
  rua;

console.log(nome, idade, comidaFavorita);