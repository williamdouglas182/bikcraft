var nome = 'André';
var idade = 28;
var possuiFaculdade = true;

console.log(nome, idade, possuiFaculdade, nome);

var preco = 25;
var totalComprado = 5;
var totalPreco = totalComprado * preco;

console.log(totalPreco);

var sobrenome = 'Rafael',
    cidade = 'Rio';

console.log(sobrenome, cidade);

var semDefinir;
console.log(semDefinir);

// console.log(aindaNaoDefine);
var comida;
console.log(comida);
comida = 'Pizza';
console.log(comida);

// const time = 'Vasco';
// time = 'Flamengo';

// console.log(time);

