var total1 = 10 + 5 + 10;
var divisao = 100 / 5;
var modulo = 3872983892 % 3;

console.log(modulo);

var testeNaN = '100' / 2;
console.log(isNaN(testeNaN));

var soma1 = (10 + 10) + 20 + 30 * 4 / (2 + 10);
console.log(soma1);

var x = 5;
console.log(x--);
console.log(x);

var idade = +'28';
var somaIdade = -5;

console.log(idade);